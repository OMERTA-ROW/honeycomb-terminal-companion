#!/bin/sh
# Opens a Terminal window and starts the Honeycomb local-network live terminal.
cd "$(dirname "$0")" || exit 1
if ! /usr/bin/python3 -c 'import sys; sys.exit(sys.version_info < (3, 9))' 2>/dev/null; then
  echo "Python 3 is needed. macOS will offer to install Command Line Tools; accept, then double-click this again."
  /usr/bin/xcode-select --install 2>/dev/null; read -r _; exit 1
fi
/usr/bin/python3 honeycomb-companion.pyz doctor
/usr/bin/python3 honeycomb-companion.pyz lan-serve
echo "Honeycomb stopped. You can close this window."; read -r _
